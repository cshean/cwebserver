I have spent 4 hours on this program so far.
I have completed all the requirements for the checkpoint
Other than needing to clean up my code I have no serious bugs that I can find in my code 
for the checkpoint version.